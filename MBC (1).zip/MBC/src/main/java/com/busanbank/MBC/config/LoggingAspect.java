package com.busanbank.MBC.config;

import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Component
@Aspect
@Slf4j
public class LoggingAspect {

	@Around("execution(* com.busanbank.MBC.controller.*.*(..))")
	public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
		log.debug("Around before : " + joinPoint.getArgs());
		try {
			Object result = joinPoint.proceed();
			HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
			String controllerName = joinPoint.getSignature().getDeclaringType().getSimpleName();
			String methodNmae = joinPoint.getSignature().getName();
			log.debug("requst : {}" , joinPoint.getArgs()[0]);
			Map<String, Object> params = new HashMap<>();
			
			try {
				params.put("controller",  controllerName);
				params.put("method",  methodNmae);
				params.put("params", getParams(request));
				params.put("log_time", new Date());
				params.put("request_uri", request.getRequestURI());
				params.put("http_method", request.getMethod());
			} catch (Exception e) {
				log.debug("LoggerAspect error", e);
			}
			log.debug("Around after: " + joinPoint.getSignature().getName());
			log.debug("params : {}" , params);
			log.debug("result : {}" , result);
			return result;
			
		} catch (Throwable throwable) {
			throw throwable;
		}
		
	}
	
	private static JSONObject getParams(HttpServletRequest request) {
		JSONObject jsonObject = new JSONObject();
		Enumeration<String> params = request.getParameterNames();
		while (params.hasMoreElements()) {
			String param = params.nextElement();
			log.info("param : {} " , param);
			String replaceParam = param.replace("\\.", "-");
			try {
				jsonObject.put(replaceParam, request.getParameter(param));
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return jsonObject;
	}
}
