package com.busanbank.MBC.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.busanbank.MBC.data.mapper.mbc.TestMapper;
import com.busanbank.MBC.data.mapper.nib.TestNIBMapper;
import com.busanbank.MBC.data.mapper.ods.TestODSMapper;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TestService {
	//private final TestMapper testMapper;
	private final TestODSMapper testODSMapper;
	private final TestNIBMapper testNIBMapper;
	
	public HashMap<String, Object> findStfInfo(HashMap<String, Object> params){
		return testODSMapper.findStfInfo(params);
	}
	
	public List<HashMap<String, Object>> findBrnoStfInfo(HashMap<String, Object> params){
		return testODSMapper.findBrnoStfInfo(params);
	}
	
	public HashMap<String, Object> findAllNIB(HashMap<String, Object> params){
		return testNIBMapper.findAllNIB(params);
	}
	
	public List<HashMap<String, Object>> fndAllNIB(HashMap<String, Object> params){
		return testNIBMapper.fndAll(params);
	}
	
}
