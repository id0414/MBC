package com.busanbank.MBC.controller;

import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.busanbank.MBC.config.SHA256Util;
import com.busanbank.MBC.service.TestService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/test")
public class TestController {
	private final TestService testService;
	private final SHA256Util sha256Util;
	
	@PostMapping("findStfInfo")
	public HashMap<String, Object> findStfInfo(@RequestBody HashMap<String, Object> params) {
		HashMap<String, Object> response = testService.findStfInfo(params);
//		List<HashMap<String, Object>> response = testService.findAllODS(params);
		try {
			String str = sha256Util.encrypt((String) params.get("str"));
			System.out.println(str);
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return response;
	}
	
	@PostMapping("findBrnoStfInfo")
	public List<HashMap<String, Object>> findBrnoStfInfo(@RequestBody HashMap<String, Object> params) {
		
		List<HashMap<String, Object>> response = testService.findBrnoStfInfo(params);
//		List<HashMap<String, Object>> response = testService.findAllODS(params);
		return response;
	}
	
	@PostMapping("findAllNIB")
	public List<HashMap<String, Object>> findAllNIB(@RequestBody HashMap<String, Object> params) {
		
		List<HashMap<String, Object>> response = testService.fndAllNIB(params);
//		HashMap<String, Object> response = testService.findAllODS(params);
		return response;
	}
	
//	@PostMapping("insertData")
//	public HashMap<String, Object> insertData(@RequestBody HashMap<String, Object> params) {
//		HashMap<String, Object> response = new HashMap<>();
//		try {
//			testService.insertData(params);
//			response.put("success", true);
//		} catch(Exception e) {
//			response.put("success", false);
//		}
//		return response;
//	}
}
