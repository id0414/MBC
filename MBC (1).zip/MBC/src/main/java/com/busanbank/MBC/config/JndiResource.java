package com.busanbank.MBC.config;

import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;
import org.apache.tomcat.util.descriptor.web.ContextResource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.embedded.tomcat.TomcatWebServer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;


import lombok.extern.slf4j.Slf4j;
//@Profile({ "D", "P" })
@Configuration
@Slf4j
public class JndiResource {

    @Value("${spring.datasource.ods.username}")
    private String odsUserName;
    
    @Value("${spring.datasource.ods.password}")
    private String odsPassword;
    
    @Value("${spring.datasource.nib.username}")
    private String nibUserName;
    
    @Value("${spring.datasource.nib.password}")
    private String nibPassword;
	
	@Bean
	public TomcatServletWebServerFactory tomcatFactory() {
		return new TomcatServletWebServerFactory() {
			@Override
			protected TomcatWebServer getTomcatWebServer(Tomcat tomcat) {
				tomcat.enableNaming();
				return super.getTomcatWebServer(tomcat);
			}
			
			@Override
			protected void postProcessContext(Context context) {
				//net.sf.log4jdbc.sql.jdbcapi.DriverSpy
				//ods																													
				context.getNamingResources().addResource(getResource("ODSDB_MBC_AP", "jdbc:log4jdbc:oracle:thin:@:DODSDB", odsUserName, odsPassword,"net.sf.log4jdbc.sql.jdbcapi.DriverSpy"));
				//nib
				context.getNamingResources().addResource(getResource("NIBDB_MBC_AP", "jdbc:log4jdbc:oracle:thin:@:DNIBDB", nibUserName, nibPassword,"net.sf.log4jdbc.sql.jdbcapi.DriverSpy"));
				// mysql 방화벽 풀릴때까지는 임시 주석
//				context.getNamingResources().addResource(getResource("MYSQL", "jdbc:log4jdbc:mysql://localhost:3306/world","mbcusr","!q2w3e4r", "net.sf.log4jdbc.sql.jdbcapi.DriverSpy"));
			}
		};
	}
	
	public ContextResource getResource(String name, String url, String username, String password, String drivername) {
		ContextResource resource = new ContextResource();
		resource.setName(name);
		resource.setType("javax.sql.DataSource");
		resource.setAuth("Container");
		log.info("jndi: {}", name);
		resource.setProperty("factory", "org.apache.commons.dbcp2.BasicDataSourceFactory");
		resource.setProperty("driverClassName", drivername);
		resource.setProperty("url", url);
		resource.setProperty("username", username);
		resource.setProperty("password", password);
		return resource;
	}
}
