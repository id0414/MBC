package com.busanbank.MBC.data.mapper.ods;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TestODSMapper {
	//단건
	HashMap<String, Object> findStfInfo(HashMap<String, Object> params);
	//다건
	List<HashMap<String, Object>> findBrnoStfInfo(HashMap<String, Object> params);
}
