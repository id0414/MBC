package com.busanbank.MBC.config;

import javax.sql.DataSource;
import javax.xml.crypto.Data;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.type.JdbcType;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Configuration
@MapperScan(basePackages = "com.busanbank.MBC.data.mapper.ods", sqlSessionFactoryRef="OdsSqlSessionFactory") // basepackage 설정 경로에 따라 mapper 못찾을 수 있음.
@EnableTransactionManagement
public class OdsDBConfig {
	
//	@Value("${spring.datasource.ods.jndi-name}")
//	private String odsDBJndiName;
	
	@Bean(name="OdsDataSource")
	@ConfigurationProperties(prefix="spring.datasource.ods")
	public DataSource OdsDataSource() {
		JndiDataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
		DataSource dataSource = dataSourceLookup.getDataSource("java:comp/env/ODSDB_MBC_AP");
		return dataSource;
	}
	
	@Bean(name="OdsSqlSessionFactory")
	public SqlSessionFactory sqlSessionFactory(@Qualifier("OdsDataSource") DataSource dataSource) throws Exception {
		
		org.apache.ibatis.session.Configuration configuration = new org.apache.ibatis.session.Configuration();
        configuration.setMapUnderscoreToCamelCase(true);
        configuration.setDefaultFetchSize(100);
        configuration.setDefaultStatementTimeout(30);
        configuration.setJdbcTypeForNull(JdbcType.NULL);
        configuration.setCallSettersOnNulls(true);
        
		final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
		sessionFactory.setDataSource(dataSource);
		PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
		sessionFactory.setMapperLocations(resolver.getResources("classpath:/META-INF/mybatis/ods/*.xml"));
		sessionFactory.setTypeAliasesPackage("com.busanbank.MBC");
		sessionFactory.setConfiguration(configuration);
		return sessionFactory.getObject();
	}
	
	@Bean(name="OdsSqlSessionTemplate")
	public SqlSessionTemplate sqlSessionTemplate(@Qualifier("OdsSqlSessionFactory") SqlSessionFactory odsSqlSessionFactory) throws Exception {
		final SqlSessionTemplate sqlSessionTemplate = new SqlSessionTemplate(odsSqlSessionFactory);
		return sqlSessionTemplate;
	}

	@Bean(name="OdsTransactionManager")
	public PlatformTransactionManager transactionManager(@Qualifier("OdsDataSource") DataSource odsDataSource) {
		return new DataSourceTransactionManager(odsDataSource);
	}
}
