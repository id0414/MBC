package com.busanbank.MBC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@EnableAspectJAutoProxy
@SpringBootApplication(scanBasePackages = {"com.busanbank.MBC"})
//@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class })
public class MbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(MbcApplication.class, args);
	}

}
