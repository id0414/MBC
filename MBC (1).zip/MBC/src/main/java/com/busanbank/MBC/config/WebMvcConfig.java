package com.busanbank.MBC.config;


//import java.util.Arrays;
//import java.util.List;

//import javax.servlet.ServletContext;
//import javax.servlet.ServletException;
//import javax.servlet.SessionCookieConfig;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.servlet.WebMvcRegistrations;
//import org.springframework.boot.web.servlet.FilterRegistrationBean;
//import org.springframework.boot.web.servlet.ServletComponentScan;
//import org.springframework.boot.web.servlet.ServletContextInitializer;
//import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
//import org.springframework.remoting.rmi.RmiServiceExporter;
//import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
//@ServletComponentScan(basePackageClasses = { SessionLoggingListener.class }) // @WebListener 스캔활성화
public class WebMvcConfig implements WebMvcConfigurer, WebMvcRegistrations {
	
	
	
//	    @Override
//	    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> resolvers) {
//	        resolvers.add(new HttpHeaderMethodArgumentResolver());
//	    }

	    /* JEUS7,8 사용불가
	    @Bean
	    public FilterRegistrationBean<HttpRequestWrapperFilter> rereadableRequestWrapperFilter() {
	        FilterRegistrationBean<HttpRequestWrapperFilter> bean = new FilterRegistrationBean<>();
	        bean.setFilter(new HttpRequestWrapperFilter());
	        bean.setUrlPatterns(Arrays.asList("/*"));
	        return bean;
	    }
	    */

//	    @Bean
//	    public ServletContextInitializer servletContextInitializer() {
//	        return new ServletContextInitializer() {
//	            @Override
//	            public void onStartup(ServletContext servletContext) throws ServletException {
//	                SessionCookieConfig config = servletContext.getSessionCookieConfig();
//	                config.setHttpOnly(true);
//	                config.setSecure(true);
//	            }
//	        };
//	    }
//
//	    @Bean
//	    public FilterRegistrationBean<MDCClearFilter> mdcClearFilter() {
//	        FilterRegistrationBean<MDCClearFilter> bean = new FilterRegistrationBean<>();
//	        bean.setFilter(new MDCClearFilter());
//	        bean.setUrlPatterns(Arrays.asList("/*"));
//	        return bean;
//	    }
//
//	    @Bean
//	    public FilterRegistrationBean<GblIdMDCPutFilter> xTrackMDCPutFilter() {
//	        FilterRegistrationBean<GblIdMDCPutFilter> bean = new FilterRegistrationBean<>();
//	        bean.setFilter(new GblIdMDCPutFilter());
//	        bean.setUrlPatterns(Arrays.asList("/*"));
//	        return bean;
//	    }
//
//	    // @Bean
//	    public FilterRegistrationBean<HeaderValidationFilter> headerValueFilter() {
//	        FilterRegistrationBean<HeaderValidationFilter> bean = new FilterRegistrationBean<>();
//	        bean.setFilter(new HeaderValidationFilter());
//	        bean.setUrlPatterns(Arrays.asList("/*"));
//	        return bean;
//	    }

	    @Override
	    public void addViewControllers(ViewControllerRegistry registry) {
	        registry.addRedirectViewController("error/accessDenied", "/accessDenied");
	        registry.addRedirectViewController("error/error", "/error");
	    }

	    @Override
	    public void addCorsMappings(CorsRegistry registry) {
	        registry.addMapping("/**")
	                .allowedOrigins("http://localhost:9091","http://localhost:9092")
	                .allowedMethods(HttpMethod.GET.name(), HttpMethod.POST.name())
	                .allowCredentials(true)
	                .maxAge(3600);
	    }

//	    @Autowired
//	    private RmiAdmService rmiAdmService;
//
//	    @Autowired
//	    private Constants constants;
//
//	    // ----------------------------------
//	    // RMI SERVER
//	    // ----------------------------------
//	    @Bean
//	    public RmiServiceExporter rmiServiceExporter() {
//
//	        RmiServiceExporter rmiServiceExporter = new RmiServiceExporter();
//	        rmiServiceExporter.setServiceName("RmiAdmService");
//	        rmiServiceExporter.setService(rmiAdmService);
//	        rmiServiceExporter.setServiceInterface(RmiAdmService.class);
//	        rmiServiceExporter.setRegistryPort(constants.getRmiPort());
//
//	        return rmiServiceExporter;
//	    }

}
