package com.busanbank.MBC.data.mapper.mbc;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TestMapper {
	HashMap<String, Object> findAll(HashMap<String, Object> params);
	void insertData(HashMap<String, Object> params);
}
