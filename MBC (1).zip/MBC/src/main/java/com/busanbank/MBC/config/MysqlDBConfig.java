package com.busanbank.MBC.config;

import javax.sql.DataSource;
import javax.xml.crypto.Data;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;


@MapperScan(basePackages = "com.busanbank.MBC.data.mapper.mbc", sqlSessionFactoryRef="MySqlSessionFactory")
@EnableTransactionManagement
public class MysqlDBConfig {
	
//	@Value("${spring.datasource.mysql.jndi-name}")
//	private String mysqlDBJndiName;
	
	@Bean(name="MysqlDataSource")
	@ConfigurationProperties(prefix="spring.datasource.mysql")
	public DataSource MysqlDataSource() {
		JndiDataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
		DataSource dataSource = dataSourceLookup.getDataSource("java:comp/env/MYSQL");
		return dataSource;
	}
	
	@Bean(name="MySqlSessionFactory")
	public SqlSessionFactory sqlSessionFactory(@Qualifier("MysqlDataSource") DataSource dataSource) throws Exception {
		final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
		sessionFactory.setDataSource(dataSource);
		PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
		sessionFactory.setMapperLocations(resolver.getResources("classpath:/META-INF/mybatis/mysql/*.xml"));
		sessionFactory.setTypeAliasesPackage("com.busanbank.MBC");
		return sessionFactory.getObject();
	}
	
	@Bean(name="MySqlSessionTemplate")
	public SqlSessionTemplate sqlSessionTemplate(@Qualifier("MySqlSessionFactory") SqlSessionFactory mySqlSessionFactory) throws Exception {
		final SqlSessionTemplate sqlSessionTemplate = new SqlSessionTemplate(mySqlSessionFactory);
		return sqlSessionTemplate;
	}

	@Bean(name="MysqlTransactionManager")
	public PlatformTransactionManager transactionManager(@Qualifier("MysqlDataSource") DataSource mysqlDataSource) {
		return new DataSourceTransactionManager(mysqlDataSource);
	}
}
