package com.busanbank.MBC.config;

import javax.sql.DataSource;
import javax.xml.crypto.Data;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.type.JdbcType;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Configuration
@MapperScan(basePackages = "com.busanbank.MBC.data.mapper.nib", sqlSessionFactoryRef="NibSqlSessionFactory") // basepackage 설정 경로에 따라 mapper 못찾을 수 있음.
@EnableTransactionManagement
public class NibDBConfig {
	
//	@Value("${spring.datasource.ods.jndi-name}")
//	private String odsDBJndiName;
	
	@Bean(name="NibDataSource")
	@ConfigurationProperties(prefix="spring.datasource.nib")
	public DataSource NibDataSource() {
		JndiDataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
		DataSource dataSource = dataSourceLookup.getDataSource("java:comp/env/NIBDB_MBC_AP");
		return dataSource;
	}
	
	@Bean(name="NibSqlSessionFactory")
	public SqlSessionFactory sqlSessionFactory(@Qualifier("NibDataSource") DataSource dataSource) throws Exception {
        org.apache.ibatis.session.Configuration configuration = new org.apache.ibatis.session.Configuration();
        configuration.setMapUnderscoreToCamelCase(true);
        configuration.setDefaultFetchSize(100);
        configuration.setDefaultStatementTimeout(30);
        configuration.setJdbcTypeForNull(JdbcType.NULL);
        configuration.setCallSettersOnNulls(true);
		
		
		final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
		sessionFactory.setDataSource(dataSource);
		PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
		sessionFactory.setMapperLocations(resolver.getResources("classpath:/META-INF/mybatis/nib/*.xml"));
		sessionFactory.setTypeAliasesPackage("com.busanbank.MBC");
		sessionFactory.setConfiguration(configuration);
		return sessionFactory.getObject();
	}
	
	@Bean(name="NibSqlSessionTemplate")
	public SqlSessionTemplate sqlSessionTemplate(@Qualifier("NibSqlSessionFactory") SqlSessionFactory nibSqlSessionFactory) throws Exception {
		final SqlSessionTemplate sqlSessionTemplate = new SqlSessionTemplate(nibSqlSessionFactory);
		return sqlSessionTemplate;
	}

	@Bean(name="NibTransactionManager")
	public PlatformTransactionManager transactionManager(@Qualifier("NibDataSource") DataSource nibDataSource) {
		return new DataSourceTransactionManager(nibDataSource);
	}
}
