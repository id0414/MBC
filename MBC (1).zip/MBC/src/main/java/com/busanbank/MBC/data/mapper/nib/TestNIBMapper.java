package com.busanbank.MBC.data.mapper.nib;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TestNIBMapper {
	
	HashMap<String, Object> findAllNIB(HashMap<String, Object> params);
	
	List<HashMap<String, Object>> fndAll(HashMap<String, Object> params);
}
