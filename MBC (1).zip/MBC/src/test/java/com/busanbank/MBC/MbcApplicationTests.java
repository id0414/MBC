package com.busanbank.MBC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
